# MLP for Pima Indians Dataset Serialize to JSON and HDF5
from keras.models import Sequential
from keras.layers import Flatten, Dense, Dropout
from keras.models import model_from_json
from keras.models import Model
from keras import optimizers
from keras.optimizers import SGD
from keras.utils import np_utils
from sklearn.model_selection import KFold
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.preprocessing import LabelEncoder
import numpy as np
from numpy import *
import os
# import tensorflow as tf
from keras.preprocessing.image import ImageDataGenerator
import sys, getopt



    
# fix random seed for reproducibility
np.random.seed(7)
# load pima indians dataset
dataset = np.loadtxt("PA14HWL.csv", delimiter=",")
# split into input (X) and output (Y) variables
X = dataset[:,0:78]
Y = dataset[:,78]
X = (X - mean(X)) / std(X)

dataset1 = np.loadtxt("ActiGraph_HLW_5cls.csv", delimiter=",")
X1 = dataset1[0:1052,0:78]
Y1 = dataset1[0:1052,78]
dataset2 = np.loadtxt("ActiGraph_HLW_5cls.csv", delimiter=",")
X2 = dataset2[1052:1579,0:78]
Y2 = dataset2[1052:1579,78]


dataset1_ = np.loadtxt("GENEActiv_HRW_5cls.csv", delimiter=",")
X1_ = dataset1_[420:1259,0:78]
Y1_ = dataset1_[420:1259,78]
 
dataset2_ = np.loadtxt("GENEActiv_HRW_5cls.csv", delimiter=",")
X2_ = dataset2_[0:420,0:78]
Y2_ = dataset2_[0:420,78]
#get 72% testing ACC

X1 = (X1 - mean(X1)) / std(X1)
X2 = (X2 - mean(X2)) / std(X2)

X1_ = (X1_ - mean(X1_)) / std(X1_)
X2_ = (X2_ - mean(X2_)) / std(X2_)

# encode class values as integers
encoder = LabelEncoder()
encoder.fit(Y)
encoded_Y = encoder.transform(Y)
# convert integers to dummy variables (i.e. one hot encoded)
dummy_y = np_utils.to_categorical(encoded_Y)

encoder1 = LabelEncoder()
encoder1.fit(Y1)
encoded_Y1 = encoder.transform(Y1)
# convert integers to dummy variables (i.e. one hot encoded)
dummy_y1 = np_utils.to_categorical(encoded_Y1)

encoder2 = LabelEncoder()
encoder2.fit(Y2)
encoded_Y2 = encoder.transform(Y2)
# convert integers to dummy variables (i.e. one hot encoded)
dummy_y2 = np_utils.to_categorical(encoded_Y2)

encoder1_ = LabelEncoder()
encoder1_.fit(Y1_)
encoded_Y1_ = encoder.transform(Y1_)
# convert integers to dummy variables (i.e. one hot encoded)
dummy_y1_ = np_utils.to_categorical(encoded_Y1_)

encoder2_ = LabelEncoder()
encoder2_.fit(Y2_)
encoded_Y2_ = encoder.transform(Y2_)
# convert integers to dummy variables (i.e. one hot encoded)
dummy_y2_ = np_utils.to_categorical(encoded_Y2_)

# create model
model = Sequential()
model.add(Dense(100, input_dim=78, kernel_initializer='uniform', activation='relu', name ='fc1'))
model.add(Dense(78, kernel_initializer='uniform', activation='relu', name='fc2'))
model.add(Dense(5, kernel_initializer='uniform', activation='softmax'))

def predict_classes(self, x, batch_size=32, verbose=1):
    '''Generate class predictions for the input samples
    batch by batch.
    # Arguments
        x: input data, as a Numpy array or list of Numpy arrays
            (if the model has multiple inputs).
        batch_size: integer.
        verbose: verbosity mode, 0 or 1.
    # Returns
        A numpy array of class predictions.
    '''
    proba = self.predict(x, batch_size=batch_size, verbose=verbose)
    if proba.shape[-1] > 1:
        return proba.argmax(axis=-1)
    else:
        return (proba > 0.5).astype('int32')
    
# Function to create model, required for KerasClassifier
def create_model():
    # create model
    model = Sequential()
    model.add(Dense(15, input_dim=78, activation='relu'))
    model.add(Dense(5, activation='softmax'))
    sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])
    return model
    
def Baseline(accelerometer, num_hidden1, num_hidden2, num_epoch):
    model2 = Sequential()

    if (num_hidden2>0):
        model2.add(Dense(num_hidden1, input_dim=78, kernel_initializer='uniform', activation='relu', name='fc1'))
        model2.add(Dense(num_hidden2, kernel_initializer='uniform', activation='relu', name='fc2'))
        model2.add(Dense(5, kernel_initializer='uniform', activation='softmax'))
    else:
        model2.add(Dense(num_hidden1, input_dim=78, kernel_initializer='uniform', activation='relu', name='fc2'))
        model2.add(Dense(5, kernel_initializer='uniform', activation='softmax'))
    # Compile model
    
    #model2.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    model2.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    # Fit the model
    print model2.summary()
        
    if (accelerometer=="Gen"):
        Xa = X1_
        dummy_ya = dummy_y1_
        Ya = Y1_
        Xb = X2_
        dummy_yb = dummy_y2_
        Yb = Y2_
    else:
        Xa = X1
        dummy_ya = dummy_y1
        Ya = Y1
        Xb = X2
        dummy_yb = dummy_y2
        Yb = Y2
        
#     model2.fit(Xa, dummy_ya , epochs=num_epoch, batch_size=10, shuffle=True, verbose=0)
#     
#     # model2.fit(datagen.flow(X1, Y1, 10) , 10, epochs=1000, batch_size=10, shuffle=True, verbose=0)
#     # evaluate the model
#     scores = model2.evaluate(Xa, dummy_ya, verbose=0)
#     print("%s: %.2f%%" % (model2.metrics_names[1], scores[1]*100))
#     scores = model2.evaluate(Xb, dummy_yb, verbose=0)
#     print("%s: %.2f%%" % (model2.metrics_names[1], scores[1]*100))
#     y_pred = model2.predict_classes(Xb, batch_size=1, verbose=0) 
#      
#     print "Confusion matrix"
#     print confusion_matrix(Yb, y_pred)
    
    # fix random seed for reproducibility
    seed = 7    
    np.random.seed(seed)
    # evaluate using 10-fold cross validation
    split = 12
    if (accelerometer=="Gen"):
        dataset1 = np.loadtxt("GENEActiv_HRW_5cls.csv", delimiter=",")
        Xx= dataset1[0:1259,0:78]
        Yy = dataset1[0:1259,78]
	Yy_one_hot_labels = np_utils.to_categorical(Yy, num_classes=5)
        Xx = (Xx - mean(Xx)) / std(Xx)    
        split =9
    else:
        dataset2 = np.loadtxt("ActiGraph_HLW_5cls.csv", delimiter=",")
        Xx = dataset2[0:1579,0:78]
        Yy = dataset2[0:1579,78]
	Yy_one_hot_labels = np_utils.to_categorical(Yy, num_classes=5)
        Xx = (Xx - mean(Xx)) / std(Xx)  
        split = 12
        
#     XX = np.concatenate((Xa,Xb),axis=0)
#     YY = np.concatenate((Ya,Yb),axis=0)
    # create model
    model22 = KerasClassifier(build_fn=create_model, epochs=300, batch_size=10, verbose=0)

    kfold = StratifiedKFold(n_splits=split, shuffle=True, random_state=0)
    results = cross_val_score(model22, Xx, Yy_one_hot_labels, cv=kfold)
    print(results.mean())
    
    
def BackgroundModel1():
 
    dataset1 = np.loadtxt("GENEActiv_HRW_5cls.csv", delimiter=",")
    Xx= dataset1[0:1259,0:78]
    Yy = dataset1[0:1259,78]
  
    Xx = (Xx - mean(Xx)) / std(Xx)
    # encode class values as integers
    encoder = LabelEncoder()
    encoder.fit(Yy)
    encoded_Yy = encoder.transform(Yy)
    # convert integers to dummy variables (i.e. one hot encoded)
    dummy_yy = np_utils.to_categorical(encoded_Yy)
 
    XX = np.concatenate((X,Xx),axis=0)
    YY = np.concatenate((Y,Yy),axis=0)
    dummy_YY = np.concatenate((dummy_y,dummy_yy),axis=0)
    
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    # Fit the model
    print model.summary()
    model.fit(XX, dummy_YY , epochs=1000, batch_size=10, shuffle=True, verbose=0)
    # evaluate the model
    scores = model.evaluate(XX, dummy_YY, verbose=0)
    print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
    y_pred = model.predict_classes(XX, batch_size=1, verbose=0) 
      
    print "Confusion matrix"
    print confusion_matrix(YY, y_pred)
      
      
    # serialize model to JSON
    model_json = model.to_json()
    with open("model14Gen.json", "w") as json_file:
        json_file.write(model_json)
    # serialize weights to HDF5
    model.save_weights("model14Gen.h5")
    print("Saved model to disk")
 
def BackgroundModel2():
 
    dataset2 = np.loadtxt("ActiGraph_HLW_5cls.csv", delimiter=",")
    Xx = dataset2[0:1579,0:78]
    Yy = dataset2[0:1579,78]
  
    Xx = (Xx - mean(Xx)) / std(Xx)
    # encode class values as integers
    encoder = LabelEncoder()
    encoder.fit(Yy)
    encoded_Yy = encoder.transform(Yy)
    # convert integers to dummy variables (i.e. one hot encoded)
    dummy_yy = np_utils.to_categorical(encoded_Yy)
 
    XX = np.concatenate((X,Xx),axis=0)
    YY = np.concatenate((Y,Yy),axis=0)
    dummy_YY = np.concatenate((dummy_y,dummy_yy),axis=0)
    
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    # Fit the model
    print model.summary()
    model.fit(XX, dummy_YY , epochs=1000, batch_size=10, shuffle=True, verbose=0)
    # evaluate the model
    scores = model.evaluate(XX, dummy_YY, verbose=0)
    print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
    y_pred = model.predict_classes(XX, batch_size=1, verbose=0) 
      
    print "Confusion matrix"
    print confusion_matrix(YY, y_pred)
      
      
    # serialize model to JSON
    model_json = model.to_json()
    with open("model14Acti.json", "w") as json_file:
        json_file.write(model_json)
    # serialize weights to HDF5
    model.save_weights("model14Acti.h5")
    print("Saved model to disk") 

def TransferModel(accelerometor, num_hidden1, num_hidden2, num_epoch):
        
    saved_model_json = ""
    saved_model_name = ""
    # load json and create model
    if (accelerometor=="Gen"):
        saved_model_json = "model14Gen.json"
        saved_model_name = "model14Gen.h5"
    else:
        saved_model_json = "model14Acti.json"
        saved_model_name = "model14Acti.h5"
        
    json_file = open(saved_model_json, 'r')
    loaded_model_json = json_file.read()
    json_file.close()
    loaded_model = model_from_json(loaded_model_json)
    # load weights into new model
    loaded_model.load_weights(saved_model_name)
    print("Loaded model from disk")
     
    # evaluate loaded model on test data
    loaded_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    #score = loaded_model.evaluate(X, Y, verbose=0)
    #print("%s: %.2f%%" % (loaded_model.metrics_names[1], score[1]*100))
     
    # create model
    #remove the last layer
     
    ###########################################################################
     
    loaded_model.layers.pop()
    loaded_model.layers[-1].outbound_nodes = []
    loaded_model.outputs = [model.layers[-1].output]
     # freeze all layers
    for layer in loaded_model.layers:    
        layer.trainable = False
         
    output = loaded_model.get_layer('fc2').output
    
    if (num_hidden2>0):
        output = Dense(output_dim=num_hidden1, kernel_initializer='uniform', activation='relu', name='fc3')(output)
        output = Dense(output_dim=num_hidden2, kernel_initializer='uniform', activation='relu', name='fc4')(output)
        output = Dense(output_dim=5,  kernel_initializer='uniform', activation='softmax')(output) # your newlayer Dense(...)
    else:
        output = Dense(output_dim=num_hidden1, kernel_initializer='uniform', activation='relu', name='fc3')(output)        
        output = Dense(output_dim=5,  kernel_initializer='uniform', activation='softmax')(output) # your newlayer Dense(...)

    new_model = Model(loaded_model.input, output)
      
    new_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
     
    print new_model.summary()
    new_model.fit(X1, dummy_y1, epochs=num_epoch, batch_size=10, shuffle=True, verbose=0)
    # evaluate the model
    new_scores = new_model.evaluate(X2, dummy_y2, verbose=0)
    print("%s: %.2f%%" % (new_model.metrics_names[1], new_scores[1]*100))
      
    y_pred = predict_classes(new_model, X2, batch_size=10, verbose=0) 
    # y_pred = np_utils.to_categorical(y_pred)
      
    print "Confusion matrix"
    print confusion_matrix(Y2, y_pred)
    
    
    ###########################################################################
    
def main(argv):
   accelerometer = ''
   num_hidden1 = 58
   num_hidden2 = 0
   num_epoch = 1000
   
   try:
      opts, args = getopt.getopt(argv,"ha:n:m:e",["accel=","hid1=","hid2=","epoch="])
   except getopt.GetoptError:
      #print '*.py -i <inputfile> -o <outputfile>'
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print '*.py -a <accelerometer> -n <hid1>'
         sys.exit()
      elif opt in ("-a", "--accel"):
         accelerometer = arg
      elif opt in ("-n", "--hid1"):
         num_hidden1 = int(arg)
      elif opt in ("-m", "--hid2"):
         num_hidden2 = int(arg)
      elif opt in ("-e", "--epoch"):
         num_epoch = int(arg)
   
   Baseline(accelerometer, num_hidden1, num_hidden2, num_epoch)
   #BackgroundModel2()
   #TransferModel()
    
if __name__ == "__main__":
   main(sys.argv[1:])
     
